// Public Supabase project settings. These are safe to expose in the browser.
// Never put a Supabase service_role key or any password in this file.
window.CLUB_CONFIG = {
  supabaseUrl: "PASTE_YOUR_SUPABASE_PROJECT_URL",
  supabaseAnonKey: "PASTE_YOUR_SUPABASE_ANON_KEY",
  galleryBucket: "club-gallery"
};
