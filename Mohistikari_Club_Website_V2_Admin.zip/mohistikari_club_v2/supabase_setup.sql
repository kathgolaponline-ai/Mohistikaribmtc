-- MOHISTIKARI BANDHU MAHAL TAPASILI CLUB WEBSITE
-- Run this entire script in Supabase Dashboard > SQL Editor.
-- Create the first admin user in Authentication > Users before running
-- the final INSERT statement at the bottom.

create table if not exists public.club_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.club_settings (
  id integer primary key check (id = 1),
  youtube_video_id text,
  about_text text not null default 'Mohistikari Bandhu Mahal Tapasili Club is a community club based in Mohistikari, Bagpara, Haripal, Hooghly. Established in 1987, the club brings people together through devotion, cultural celebrations and the annual spirit of Kali Puja.',
  updated_at timestamptz not null default now()
);
insert into public.club_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.club_gallery (
  id bigint generated always as identity primary key,
  image_url text not null,
  storage_path text not null,
  caption text not null default 'Kali Puja memory',
  created_at timestamptz not null default now()
);

alter table public.club_admins enable row level security;
alter table public.club_settings enable row level security;
alter table public.club_gallery enable row level security;

drop policy if exists "Admins can read own admin record" on public.club_admins;
create policy "Admins can read own admin record" on public.club_admins
for select to authenticated using (user_id = auth.uid());

drop policy if exists "Public can read club settings" on public.club_settings;
create policy "Public can read club settings" on public.club_settings
for select to anon, authenticated using (true);
drop policy if exists "Admins can update club settings" on public.club_settings;
create policy "Admins can update club settings" on public.club_settings
for update to authenticated using (
  exists (select 1 from public.club_admins a where a.user_id = auth.uid())
) with check (
  exists (select 1 from public.club_admins a where a.user_id = auth.uid())
);
drop policy if exists "Admins can insert club settings" on public.club_settings;
create policy "Admins can insert club settings" on public.club_settings
for insert to authenticated with check (
  exists (select 1 from public.club_admins a where a.user_id = auth.uid())
);

drop policy if exists "Public can read gallery" on public.club_gallery;
create policy "Public can read gallery" on public.club_gallery
for select to anon, authenticated using (true);
drop policy if exists "Admins can add gallery photos" on public.club_gallery;
create policy "Admins can add gallery photos" on public.club_gallery
for insert to authenticated with check (
  exists (select 1 from public.club_admins a where a.user_id = auth.uid())
);
drop policy if exists "Admins can delete gallery photos" on public.club_gallery;
create policy "Admins can delete gallery photos" on public.club_gallery
for delete to authenticated using (
  exists (select 1 from public.club_admins a where a.user_id = auth.uid())
);

-- Create a PUBLIC storage bucket so visitors can view published gallery images.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('club-gallery', 'club-gallery', true, 10485760, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 10485760,
allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "Public can view club gallery images" on storage.objects;
create policy "Public can view club gallery images" on storage.objects
for select to anon, authenticated using (bucket_id = 'club-gallery');

drop policy if exists "Club admins can upload gallery images" on storage.objects;
create policy "Club admins can upload gallery images" on storage.objects
for insert to authenticated with check (
  bucket_id = 'club-gallery' and
  exists (select 1 from public.club_admins a where a.user_id = auth.uid())
);

drop policy if exists "Club admins can delete gallery images" on storage.objects;
create policy "Club admins can delete gallery images" on storage.objects
for delete to authenticated using (
  bucket_id = 'club-gallery' and
  exists (select 1 from public.club_admins a where a.user_id = auth.uid())
);

-- IMPORTANT: After creating your first user in Authentication > Users,
-- copy that user's UUID and replace YOUR_AUTH_USER_UUID below.
-- Run this one statement separately:
-- insert into public.club_admins (user_id) values ('YOUR_AUTH_USER_UUID');
